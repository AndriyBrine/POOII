public class Atv1_Revisao {

    public static void main(String[] args){
        
        Caneta c1 = new Caneta();
        c1.cor = "Azul";
        c1.ponta = 0.5f; // Chamada a atributo (não tem parenteses)
        c1.tampar();
        // c1.status(); // Chamada a Método (tem parenteses)
        c1.rabiscar();

        Caneta c2 = new Caneta();
        c2.modelo = "Hostnet";
        c2.cor = "Preta";
        c2.destampar();
        c2.rabiscar();
    }
}