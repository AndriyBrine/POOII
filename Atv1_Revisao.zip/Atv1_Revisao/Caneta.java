public class Caneta {

    String modelo; String cor; float ponta; int carga; boolean tampada;

    void status() {// Void = sem retorno
        System.out.println("Uma caneta " + this.modelo);
        System.out.println("Minha cor é: " + this.cor);
        System.out.println("Minha ponta é: " + this.ponta);
        System.out.println("Estou carregada com: " + this.carga);
        System.out.println("Estou tampada: " + this.tampada);
    }

    void rabiscar(){
        if (this.tampada == true){
            System.out.println("Erro! Não posso rabiscar.");
        }
        else {
            System.out.println("Estou rabiscando!");
        }
    }

    void tampar() {
        this.tampada = true; // this é o nome do objeto que foi chamado
    }

    void destampar(){
        this.tampada = false;
    }
}